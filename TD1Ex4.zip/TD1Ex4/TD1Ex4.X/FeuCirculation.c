#include "FeuCirculation.h"

void
main ()
{
  ADCON1 = 0x06;
  TRISA = 0x01;

  short i;
  TRISB = 0x00; // output

  //tester les LEDs pandant 3 secondes
  PORTD = 0xFF; //
  TRISD = 0x00; // output
  __delay_ms (3000);

  while (1)
    {
      GREEN2 = !GREEN2;
      i = 0;

      while (i < 100)
        {
          if (GREEN2)
            PORTD = 0x8C;
          else
            PORTD = 0x61;

          if (RA0)
            {
              GREEN2 = 1;
              i = 0;
              continue;
            }
          __delay_ms (period);
          i++;
        }

      i = 0;
      while (i < 10)
        {
          YELLOW0 = !YELLOW0 && GREEN0;
          YELLOW1 = !YELLOW1 && GREEN1;
          if (RA0)
            {
              GREEN2 = 0;
              break;
            }
          __delay_ms (period);
          i++;
        }

    }
}



