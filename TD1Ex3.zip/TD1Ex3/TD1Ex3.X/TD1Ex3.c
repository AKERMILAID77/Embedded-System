/*
 * File:   TD1Ex3.c
 * Author: laid
 *
 * Created on September 20, 2022, 5:58 PM
 */

#include <xc.h>

// PIC16F877 Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config CP = OFF         // FLASH Program Memory Code Protection bits (Code protection off)
#pragma config BOREN = OFF      // Brown-out Reset Enable bit (BOR disabled)
#pragma config LVP = OFF        // Low Voltage In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EE Memory Code Protection (Code Protection off)
#pragma config WRT = OFF        // FLASH Program Memory Write Enable (Unprotected program memory may not be written to by EECON control)

// #pragma config statements should precede project file includes.
// Use project enums instead of #define for ON and OFF.

#define _XTAL_FREQ 2000000
#define LED0 RB4
#define LED1 RB5
#define LED2 RB6
#define LED3 RB7

void
main (void)
{
  PORTB = 0x00;
  TRISB = 0x0F;
  OPTION_REG |= (1 << 7); //D�sactivation de Pull-Up

  while (1)
    {
      if ((RB1 & RB2) | RB3)
        LED0 = 1;
      else
        LED0 = 0;

      if ((RB1 | !RB2) & RB3)
        LED1 = 1;
      else
        LED1 = 0;

      if (RB1 ^ RB2)
        LED2 = 1;
      else
        LED2 = 0;

      if (RB1 ^ RB2)
        LED3 = 0;
      else
        LED3 = 1;
    }
}

/*
 Simplification:
 * RB0 n'est pas utilis�
 * LED3 = !LED2
 */